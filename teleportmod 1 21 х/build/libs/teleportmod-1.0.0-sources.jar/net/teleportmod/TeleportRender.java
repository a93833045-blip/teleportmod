package net.teleportmod;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import org.lwjgl.glfw.GLFW;

public class TeleportRender {

    /**
     * Рендерит Portal-Style оверлей выбора варпов по JSON-ключу action.warp.
     * Автоматически скармливает игре плейсхолдеры %s и %d на уровне движка.
     */
    public static class_2561 getWarpMenuText() {
        if (TeleportData.warpList.isEmpty()) {
            return class_2561.method_43471("menu.empty").method_27692(class_124.field_1061);
        }
        if (TeleportData.warpIndex >= TeleportData.warpList.size()) TeleportData.warpIndex = 0;
        
        // Нативная передача аргументов: (Имя варпа, Текущий номер, Всего варпов)
        return class_2561.method_43469(
            "action.warp", 
            TeleportData.warpList.get(TeleportData.warpIndex), 
            Integer.valueOf(TeleportData.warpIndex + 1), 
            Integer.valueOf(TeleportData.warpList.size())
        );
    }

    /**
     * Рендерит оверлей быстрого выбора игроков из ТАБа.
     */
    public static class_2561 getPlayerMenuText() {
        if (TeleportData.playersTab.isEmpty() || TeleportData.playersTab.get(0).equals("No_Players")) {
            return class_2561.method_43471("menu.empty").method_27692(class_124.field_1061);
        }
        if (TeleportData.playerIndex >= TeleportData.playersTab.size()) TeleportData.playerIndex = 0;
        
        class_5250 widget = class_2561.method_43470("[ВЫБОР ИГРОКА] ").method_27695(class_124.field_1064, class_124.field_1067);
        widget.method_10852(class_2561.method_43470("(Вверх/Вниз) ").method_27692(class_124.field_1054));
        widget.method_10852(class_2561.method_43470("> ").method_27695(class_124.field_1076, class_124.field_1067));
        widget.method_10852(class_2561.method_43470(TeleportData.playersTab.get(TeleportData.playerIndex)).method_27695(class_124.field_1060, class_124.field_1067));
        widget.method_10852(class_2561.method_43470(" < ").method_27695(class_124.field_1076, class_124.field_1067));
        
        String counter = "(" + (TeleportData.playerIndex + 1) + "/" + TeleportData.playersTab.size() + ")";
        return widget.method_10852(class_2561.method_43470(counter).method_27692(class_124.field_1063));
    }

    /**
     * Рендерит трёхцветный светофор подсказки состояния /tpa или /tp запроса.
     * Загорается строго на 3 секунды при одиночном клике или после отправки.
     */
    public static class_2561 getTpaStatusText(class_310 client, long now) {
        if (now > TeleportData.statusShowUntil) return class_2561.method_43473();
        
        if (TeleportData.selectedPlayer == null || TeleportData.selectedPlayer.isEmpty()) {
            if (TeleportData.isPlayerMenuOpen) {
                return class_2561.method_43470("Игрок не выбран").method_27692(class_124.field_1061);
            }
            return class_2561.method_43473();
        }

        class_124 color = class_124.field_1061; // Офлайн (По умолчанию красным)
        
        if (now - TeleportData.tpaRequestTimestamp < 15000) {
            color = class_124.field_1054; // Запрос только что отправлен (Жёлтый приоритет)
        } else if (client.method_1562() != null) {
            for (class_640 entry : client.method_1562().method_2880()) {
                String name = TeleportData.getCleanPlayerName(entry);
                if (name.equalsIgnoreCase(TeleportData.selectedPlayer)) { 
                    color = class_124.field_1060; // Цель найдена в онлайне ТАБа (Зелёный)
                    break; 
                } 
            }
        }
        
        String cmdPrefix = TeleportData.isTpMode ? "/tp " : "/tpa ";
        return class_2561.method_43470(cmdPrefix + TeleportData.selectedPlayer).method_27692(color);
    }
    /**
     * Рендерит градиентную шкалу отката RTP по JSON-ключам.
     */
    public static class_2561 getRtpCooldownText(long now) {
        class_5250 component = class_2561.method_43473();
        if (now < TeleportData.cooldownEndTimestamp) {
            long remainingMs = TeleportData.cooldownEndTimestamp - now;
            long secondsLeft = (remainingMs + 999) / 1000;
            
            // Запрашиваем нативный перевод отката, передавая оставшиеся секунды в %d
            class_2561 cdText = class_2561.method_43469("action.rtp.cd", secondsLeft);
            double percentage = (double) remainingMs / (TeleportData.cooldownDurationSec * 1000);
            
            // Алгоритм мягкой смены цвета в зависимости от остатка времени
            class_124 color = class_124.field_1060;
            if (percentage > 0.75) color = class_124.field_1079;
            else if (percentage > 0.50) color = class_124.field_1065;
            else if (percentage > 0.25) color = class_124.field_1054;
            
            component.method_10852(cdText.method_27661().method_27692(color));
        } else if (TeleportData.cooldownEndTimestamp > 0) {
            // Кулдаун иссяк — запускаем 3-секундный таймер надписи "Телепорт готов!"
            TeleportData.hideReadyNotificationTimestamp = now + 3000;
            TeleportData.cooldownEndTimestamp = 0;
        }

        if (now < TeleportData.hideReadyNotificationTimestamp && TeleportData.cooldownEndTimestamp == 0) {
            component.method_10852(class_2561.method_43471("action.rtp.ready").method_27692(class_124.field_1060));
        }
        return component;
    }

    /**
     * Полностью переписанный на MutableText и translatable-компоненты менеджер настроек.
     * На ходу адаптирует интерфейс под русскую и английскую раскладки.
     */
    public static class_2561 buildConfigMenuText() {
        class_5250 menu = class_2561.method_43473();
        
        // Подгружаем заголовок "[НАСТРОЙКА] " или "[SETTINGS] "
        menu.method_10852(class_2561.method_43471("menu.config").method_27695(class_124.field_1076, class_124.field_1067));
        menu.method_27693(" "); 
        
        if (TeleportData.isWaitingForBind) {
            return menu.method_10852(class_2561.method_43471("menu.waitkey").method_27695(class_124.field_1076, class_124.field_1067));
        }
        
        class_5250 rowText = class_2561.method_43473().method_27692(class_124.field_1054);
        rowText.method_27693("§e> "); // Стрелочка активной строки выбора
        
        switch (TeleportData.configSelectRow) {
            case 0: rowText.method_10852(class_2561.method_43471("menu.home")).method_10852(class_2561.method_43470(getKeyName(TeleportData.tempKeyHome)).method_27692(class_124.field_1068)); break;
            case 1: rowText.method_10852(class_2561.method_43471("menu.rtp")).method_10852(class_2561.method_43470(getKeyName(TeleportData.tempKeyRtp)).method_27692(class_124.field_1068)); break;
            case 2: rowText.method_10852(class_2561.method_43471("menu.spawn")).method_10852(class_2561.method_43470(getKeyName(TeleportData.tempKeySpawn)).method_27692(class_124.field_1068)); break;
            case 3: rowText.method_10852(class_2561.method_43471("menu.warp")).method_10852(class_2561.method_43470(getKeyName(TeleportData.tempKeyWarp)).method_27692(class_124.field_1068)); break;
            case 4: rowText.method_10852(class_2561.method_43471("menu.tpa")).method_10852(class_2561.method_43470(getKeyName(TeleportData.tempKeyTpa)).method_27692(class_124.field_1068)); break;
            case 5: 
                rowText.method_10852(class_2561.method_43471("menu.cooldown"))
                       .method_10852(class_2561.method_43470(Long.toString(TeleportData.tempCooldownDurationSec)).method_27692(class_124.field_1068))
                       .method_10852(class_2561.method_43471("menu.sec")); 
                break;
            case 6: 
                String modeName = TeleportData.tempTpMode ? "/tp (Admin)" : "/tpa (Request)";
                rowText.method_10852(class_2561.method_43471("menu.mode")).method_10852(class_2561.method_43470(modeName).method_27692(class_124.field_1068)); 
                break;
            case 7: rowText.method_10852(class_2561.method_43471("menu.add")); break;
            case 8:
                rowText.method_10852(class_2561.method_43471("menu.delete"));
                if (TeleportData.tempWarpList.isEmpty()) {
                    rowText.method_10852(class_2561.method_43471("menu.empty"));
                } else {
                    if (TeleportData.deleteWarpIndex >= TeleportData.tempWarpList.size()) TeleportData.deleteWarpIndex = TeleportData.tempWarpList.size() - 1;
                    rowText.method_10852(class_2561.method_43470(TeleportData.tempWarpList.get(TeleportData.deleteWarpIndex)).method_27692(class_124.field_1068));
                }
                rowText.method_27693(" ] <");
                break;
            case 9: rowText.method_10852(class_2561.method_43471("menu.addplayer")); break;
            case 10: rowText.method_10852(class_2561.method_43471("menu.clearplayer")); break;
            case 11: rowText.method_10852(class_2561.method_43471("menu.instruction")); break;
            case 12: rowText.method_10852(class_2561.method_43471("menu.save")); break;
            case 13: rowText.method_10852(class_2561.method_43471("menu.cancel")); break;
        }
        
        if (TeleportData.configSelectRow != 8) {
            rowText.method_27693(" <");
        }
        
        menu.method_10852(rowText);
        
        // Порядковый счётчик строк "(1/14)" в самом конце
        String counter = " §8(" + (TeleportData.configSelectRow + 1) + "/14)";
        menu.method_10852(class_2561.method_43470(counter).method_27692(class_124.field_1063));
        
        return menu;
    }

    @Deprecated
    public static String buildConfigString() {
        return "";
    }

    public static String getKeyName(int code) {
        String name = GLFW.glfwGetKeyName(code, 0);
        if (name == null || name.isEmpty()) {
            if (code == GLFW.GLFW_KEY_SPACE) return "SPACE";
            if (code == GLFW.GLFW_KEY_ENTER) return "ENTER";
            return "Key_" + code;
        }
        return name.toUpperCase();
    }

    /**
     * Построчно выгружает монументальную цветную инструкцию из 18 строк в чат игрока.
     */
    public static void printInstruction(class_310 client) {
        if (client.field_1724 == null) return;
        for (int i = 1; i <= 18; i++) {
            class_2561 msg = class_2561.method_43471("ins.line" + i);
            if (!msg.getString().equals("ins.line" + i)) { 
                client.field_1724.method_7353(msg, false); 
            }
        }
    }
}
