package net.teleportmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class TeleportModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        TeleportData.load();

        // Силовая принудительная инициализация резервного перевода.
        // Если у пользователя включен любой региональный английский (en_gb, en_ca), 
        // движок игры автоматически подтянет строки из нашего базового en_us.json!
        try {
            class_1074.method_4662("category.teleportmod");
        } catch (Exception ignored) {}

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;
            long now = System.currentTimeMillis();
            long windowHandle = client.method_22683().method_4490();

            TeleportLogic.processInputs(client, now, windowHandle);

            if (client.field_1755 == null) {
                if (TeleportData.isConfigMenuOpen) {
                    client.field_1724.method_7353(TeleportRender.buildConfigMenuText(), true);
                } else if (TeleportData.isPlayerMenuOpen) {
                    client.field_1724.method_7353(TeleportRender.getPlayerMenuText(), true);
                } else {
                    class_5250 finalMessage = class_2561.method_43473();
                    
                    class_2561 tpaStatus = TeleportRender.getTpaStatusText(client, now);
                    if (!tpaStatus.getString().isEmpty()) {
                        finalMessage.method_10852(tpaStatus);
                        finalMessage.method_27693(" ");
                    }

                    class_2561 rtpCd = TeleportRender.getRtpCooldownText(now);
                    if (!rtpCd.getString().isEmpty()) {
                        finalMessage.method_10852(rtpCd);
                    }

                    if (TeleportData.isWarpMenuOpen) {
                        if (!finalMessage.getString().isEmpty()) finalMessage.method_27693(" ");
                        finalMessage.method_10852(TeleportRender.getWarpMenuText());
                    }

                    if (!finalMessage.getString().isEmpty()) {
                        client.field_1724.method_7353(finalMessage, true);
                    }
                }
            }
        });
    }
}
